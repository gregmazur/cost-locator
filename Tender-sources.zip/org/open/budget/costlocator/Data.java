
package org.open.budget.costlocator;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("procurementMethod")
    @Expose
    private String procurementMethod;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("tenderPeriod")
    @Expose
    private TenderPeriod tenderPeriod;
    @SerializedName("documents")
    @Expose
    private List<Document> documents = null;
    @SerializedName("numberOfBids")
    @Expose
    private Long numberOfBids;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("minimalStep")
    @Expose
    private MinimalStep minimalStep;
    @SerializedName("items")
    @Expose
    private List<Item> items = null;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("procurementMethodType")
    @Expose
    private String procurementMethodType;
    @SerializedName("value")
    @Expose
    private Value value;
    @SerializedName("submissionMethod")
    @Expose
    private String submissionMethod;
    @SerializedName("procuringEntity")
    @Expose
    private ProcuringEntity procuringEntity;
    @SerializedName("owner")
    @Expose
    private String owner;
    @SerializedName("tenderID")
    @Expose
    private String tenderID;
    @SerializedName("enquiryPeriod")
    @Expose
    private EnquiryPeriod enquiryPeriod;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("guarantee")
    @Expose
    private Guarantee guarantee;
    @SerializedName("dateModified")
    @Expose
    private String dateModified;
    @SerializedName("awardCriteria")
    @Expose
    private String awardCriteria;

    public String getProcurementMethod() {
        return procurementMethod;
    }

    public void setProcurementMethod(String procurementMethod) {
        this.procurementMethod = procurementMethod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public TenderPeriod getTenderPeriod() {
        return tenderPeriod;
    }

    public void setTenderPeriod(TenderPeriod tenderPeriod) {
        this.tenderPeriod = tenderPeriod;
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    public Long getNumberOfBids() {
        return numberOfBids;
    }

    public void setNumberOfBids(Long numberOfBids) {
        this.numberOfBids = numberOfBids;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public MinimalStep getMinimalStep() {
        return minimalStep;
    }

    public void setMinimalStep(MinimalStep minimalStep) {
        this.minimalStep = minimalStep;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProcurementMethodType() {
        return procurementMethodType;
    }

    public void setProcurementMethodType(String procurementMethodType) {
        this.procurementMethodType = procurementMethodType;
    }

    public Value getValue() {
        return value;
    }

    public void setValue(Value value) {
        this.value = value;
    }

    public String getSubmissionMethod() {
        return submissionMethod;
    }

    public void setSubmissionMethod(String submissionMethod) {
        this.submissionMethod = submissionMethod;
    }

    public ProcuringEntity getProcuringEntity() {
        return procuringEntity;
    }

    public void setProcuringEntity(ProcuringEntity procuringEntity) {
        this.procuringEntity = procuringEntity;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getTenderID() {
        return tenderID;
    }

    public void setTenderID(String tenderID) {
        this.tenderID = tenderID;
    }

    public EnquiryPeriod getEnquiryPeriod() {
        return enquiryPeriod;
    }

    public void setEnquiryPeriod(EnquiryPeriod enquiryPeriod) {
        this.enquiryPeriod = enquiryPeriod;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Guarantee getGuarantee() {
        return guarantee;
    }

    public void setGuarantee(Guarantee guarantee) {
        this.guarantee = guarantee;
    }

    public String getDateModified() {
        return dateModified;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public String getAwardCriteria() {
        return awardCriteria;
    }

    public void setAwardCriteria(String awardCriteria) {
        this.awardCriteria = awardCriteria;
    }

}
